package com.avirantenterprises.infocollector.service;

import com.avirantenterprises.infocollector.model.Form;
import com.avirantenterprises.infocollector.repository.FormRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FormServiceImpl implements FormService {
    @Autowired
    private FormRepository formRepository;
    @Override
    public void saveData(Form form) {
        formRepository.save(form);
    }

    @Override
    public Iterable<Form> findAllData() {
        return formRepository.findAll();
    }

    @Override
    public Form getDataById(Long id) {
        return formRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteData(Long id) {
        formRepository.deleteById(id);
    }
}