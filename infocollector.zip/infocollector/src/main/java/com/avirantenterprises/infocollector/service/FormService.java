package com.avirantenterprises.infocollector.service;

import com.avirantenterprises.infocollector.model.Form;

public interface FormService {
    static Form getFormByid(Long id) {
        return null;
    }

    void saveData(Form form);
    Iterable<Form> findAllData();
    Form getDataById(Long id);
    void deleteData(Long id);
}