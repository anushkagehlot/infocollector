package com.avirantenterprises.infocollector.controller;

import com.avirantenterprises.infocollector.model.Form;
import com.avirantenterprises.infocollector.model.Form1;
import com.avirantenterprises.infocollector.repository.Form1Repository;
import com.avirantenterprises.infocollector.repository.FormRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;


@Controller
public class FormBuilderController {
    @Autowired
    private Form1Repository form1Repository;
    @GetMapping("/formBuilder")
    public String formBuilder(Model model){
        model.addAttribute("form1",new Form1());
        return "formBuilder";
    }
    @GetMapping("/saveForm")
    public String saveForm(@ModelAttribute("form1") Form1 form1){
        form1Repository.save(form1);
        return "redirect:/forms";
    }
    @GetMapping ("/form1")
    public String showForm(Model model){
        model.addAttribute("forms",form1Repository.findAll());
        return "forms";
    }
}
