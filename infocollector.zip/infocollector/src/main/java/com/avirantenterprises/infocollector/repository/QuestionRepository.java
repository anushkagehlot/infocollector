package com.avirantenterprises.infocollector.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.avirantenterprises.infocollector.model.Question;

public interface QuestionRepository extends JpaRepository<Question,Long> {
}
