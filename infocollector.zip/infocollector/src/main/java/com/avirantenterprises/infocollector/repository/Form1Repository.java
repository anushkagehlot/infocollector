package com.avirantenterprises.infocollector.repository;

import com.avirantenterprises.infocollector.model.Form1;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Form1Repository extends JpaRepository<Form1 ,Long> {
}

