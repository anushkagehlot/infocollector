package com.avirantenterprises.infocollector.controller;

import com.avirantenterprises.infocollector.model.Form;
import com.avirantenterprises.infocollector.service.FormService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import javax.xml.crypto.Data;

@Controller
public class FormController {
    @Autowired
    private FormService formService;

    @GetMapping("/form")
    public String form(Model model)
    {
        model.addAttribute("formList",formService.findAllData());
        return "form";
    }

    @GetMapping("/registerData")
    public String registerData(Model model)
    {
        Form form=new Form();
        model.addAttribute("form",form);
        return "registerData";
    }
    @PostMapping("/saveData")
    public String saveData(@ModelAttribute("form")Form form)
    {
        formService.saveData(form);
        return "redirect:/form";
    }
    @GetMapping ("/updateData/id")
    public String updateData(Model model, @PathVariable Long
                             id){
        Form form = FormService.getFormByid(id);
        model.addAttribute("form", form);
        return "updateFormData";
    }
    @GetMapping("/deleteData/{id}")
    public String deleteData(@PathVariable Long id){
        formService.deleteData(id);
        return "redirect:/form";
    }


}

